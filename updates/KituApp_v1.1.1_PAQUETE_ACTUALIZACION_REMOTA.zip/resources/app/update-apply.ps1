param(
  [Parameter(Mandatory=$true)][string]$TargetRoot,
  [Parameter(Mandatory=$true)][string]$ArchivePath,
  [Parameter(Mandatory=$true)][int]$AppPid,
  [Parameter(Mandatory=$true)][string]$Version,
  [Parameter(Mandatory=$true)][string]$LogPath
)
$ErrorActionPreference = 'Stop'
function Write-KituLog([string]$message) {
  try { Add-Content -LiteralPath $LogPath -Value ("$(Get-Date -Format o) $message") -Encoding UTF8 } catch {}
}
$stage=$null
$backup=$null
$changed=New-Object 'System.Collections.Generic.List[string]'
$created=New-Object 'System.Collections.Generic.List[string]'
try {
  Add-Type -AssemblyName System.IO.Compression
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $TargetRoot=[IO.Path]::GetFullPath($TargetRoot)
  if (-not (Test-Path -LiteralPath (Join-Path $TargetRoot 'Kitu App.exe') -PathType Leaf)) {throw 'No se encontró Kitu App.exe en la carpeta de destino'}
  if (-not (Test-Path -LiteralPath $ArchivePath -PathType Leaf)) {throw 'No se encontró el ZIP firmado'}
  $i=0
  while ((Get-Process -Id $AppPid -ErrorAction SilentlyContinue) -and $i -lt 90) {Start-Sleep -Seconds 1;$i++}
  if (Get-Process -Id $AppPid -ErrorAction SilentlyContinue) {throw 'KituApp sigue abierta; no se aplicó el parche'}
  $updatesHome=Split-Path -Parent $LogPath
  $stage=Join-Path $updatesHome ("stage_"+[guid]::NewGuid().ToString('N'))
  $backup=Join-Path $updatesHome ("backup_"+$Version+"_"+(Get-Date -Format 'yyyyMMddHHmmss'))
  New-Item -ItemType Directory -Force -Path $stage,$backup | Out-Null
  $zip=[System.IO.Compression.ZipFile]::OpenRead($ArchivePath)
  try {
    $files=New-Object 'System.Collections.Generic.List[object]'
    $seen=@{}
    $expanded = [int64]0
    foreach($entry in $zip.Entries){
      $expanded += $entry.Length
      if ($expanded -gt (512 * 1024 * 1024)) {throw 'Paquete descomprimido demasiado grande'}
      $p=$entry.FullName.Replace('\','/')
      if (!$p -or $p.EndsWith('/')) {continue}
      if ($p.StartsWith('/') -or $p -match '(^|/)\.\.(/|$)' -or $p -match '(^|/)\.(/|$)' -or $p.Contains(':')) {throw "Ruta insegura: $p"}
      if (!$p.StartsWith('kitu/') -and !$p.StartsWith('resources/app/')) {throw "El parche intenta modificar un motor u otra ruta no autorizada: $p"}
      if ($seen.ContainsKey($p)) {throw "Archivo duplicado: $p"}
      $seen[$p]=$true
      $files.Add(@{Entry=$entry; Rel=$p})
    }
    if ($files.Count -lt 1 -or $files.Count -gt 500) {throw 'Cantidad de archivos inesperada'}
    foreach($item in $files){
      $localPath=Join-Path $stage ($item.Rel.Replace('/','\'))
      $parent=Split-Path -Parent $localPath
      New-Item -ItemType Directory -Force -Path $parent | Out-Null
      [System.IO.Compression.ZipFileExtensions]::ExtractToFile($item.Entry,$localPath,$false)
    }
  } finally {$zip.Dispose()}
  # After every file is validated and extracted, back up and install only changed files.
  foreach($f in Get-ChildItem -LiteralPath $stage -Recurse -File){
    $rel=$f.FullName.Substring($stage.Length+1)
    $dest=Join-Path $TargetRoot $rel
    $parent=Split-Path -Parent $dest
    if (!(Test-Path -LiteralPath $parent)) {New-Item -ItemType Directory -Force -Path $parent | Out-Null}
    if (Test-Path -LiteralPath $dest -PathType Leaf){
      $old=Join-Path $backup $rel
      New-Item -ItemType Directory -Force -Path (Split-Path -Parent $old) | Out-Null
      Copy-Item -LiteralPath $dest -Destination $old -Force
      $changed.Add($rel)
    } else {$created.Add($rel)}
    Copy-Item -LiteralPath $f.FullName -Destination $dest -Force
  }
  Write-KituLog "Installed KituApp $Version ($($files.Count) files); backup: $backup"
  Start-Process -FilePath (Join-Path $TargetRoot 'Kitu App.exe') -WorkingDirectory $TargetRoot
} catch {
  Write-KituLog "FAILED: $($_.Exception.Message)"
  if ($backup -and (Test-Path -LiteralPath $backup)) {
    foreach($rel in $changed) {
      $src=Join-Path $backup $rel;$dst=Join-Path $TargetRoot $rel
      try {if(Test-Path -LiteralPath $src){Copy-Item -LiteralPath $src -Destination $dst -Force}}catch {Write-KituLog "Rollback failed: $rel"}
    }
    foreach($rel in $created) {
      try {Remove-Item -LiteralPath (Join-Path $TargetRoot $rel) -Force -ErrorAction SilentlyContinue}catch{}
    }
  }
  exit 1
} finally {
  if ($stage -and (Test-Path -LiteralPath $stage)) {Remove-Item -LiteralPath $stage -Force -Recurse -ErrorAction SilentlyContinue}
}
